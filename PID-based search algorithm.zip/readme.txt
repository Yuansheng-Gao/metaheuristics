PID-based search algorithm (PSA)
 
email: gaoyuansheng2021@163.com

The files in this zip archive are MATLAB m-files that can be used to study PID-based search algorithm.

PSA is the method that I invented and wrote about in the following paper:
Yuansheng Gao, PID-based search algorithm: A novel metaheuristic algorithm based on PID algorithm.

The MATLAB files and their descriptions are as follows:
GetFunctionsDetails.m
This is the benchmark functions. You can use it as template to write your own function if you are interested in testing or optimizing some other functions. 
PSA.m
This is the core code of the PSA.
Initialization.m
This contains various initialization settings for the optimization methods. 
I hope that this software is as interesting and useful to you as is to me. Feel free to contact me with any comments or questions.