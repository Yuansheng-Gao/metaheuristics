%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                         %
%  Science Progress Optimizer (SPO) source codes version 1.0              %
%                                                                         %
%  Developed in:   MATLAB R2018b                                          %
%                                                                         %
%  Programmer:     Yuansheng Gao                                          %
%                  e-mail: gaoyuansheng2021@163.com                       %
%                                                                         %
%  Original paper: Yuansheng Gao, Jinpeng Wang#, Lang Qin#, Jiahui Zhang, %
%                  Yulin Wang     # Equal contribution                    %
%				   Let All Be Guides! Science Progress Optimizer for      %
%                  Global Optimization                                    %
%                                                                         %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [Bestx,BestF,ConvergenceCurve] = SPO (fun,dim,lb,ub,structure)
%% Initialization
PopSize = structure.PopSize;               % The size of the population
T = structure.T;                           % Maximum number of iterations
ConvergenceCurve  = zeros (1, T);          % Convergence curve
% Initialize the population
x=initialization(PopSize,dim,ub,lb);

% Calculate the fitness value
F = zeros(PopSize,1);                  
BestF = inf;
t = 0;
for i = 1:PopSize
    t=t+1;if t>T;break;end
    F(i) = fun (x(i,:));
    if BestF>F(i)
        BestF = F(i);                                 % Fitness value of the black hole
        Bestx = x(i,:);                               % Position of black hole
    end
    ConvergenceCurve(t) = BestF;
end
% Initialize parameters and related variables
vs = zeros(PopSize,dim);                              % The tangential direction time-velocity
vn = zeros(PopSize,dim);                              % The gravity direction time-velocity
vt = [];
%% main loop
k = 0;
while t<T
    % Enforce bounds
    lbExtended = repmat (lb,[PopSize,dim]);
    ubExtended = repmat (ub,[PopSize,dim]);
    k = k+1;
    InitD = Bestx-x;
    c1 = (1-t/T);
    d = (rand(PopSize,1)*c1+1).*nthroot(sum(InitD.^2,2),2);
    d(d==0) = sum(d)/(PopSize-sum(d==0));

    % Calculate the gravitational direction time-velocity and the tangential direction time-velocity
    for i = 1 : PopSize
        D = ( x - x(i,:) ).*rand(PopSize,1);
        vn(i,:) = sum(rand(1,dim).*D,1);
        Dvn = sqrt(sum((vn(i,:).^2)))+eps;
        vn(i,:) = vn(i,:)./Dvn;
        if isempty(vt)
            vs(i,:) = vn(i,:);
        else
            Dvt = sqrt(sum(vt(i,:).^2))+eps;
            vs(i,:) = vt(i,:)./Dvt;
        end
    end

    % Calculate the resultant time-velocity
    vt = (rand(PopSize, 1).*vn + rand(PopSize, 1).*vs).*d;
    
    
    % Update the positions of heavenly bodies
	xn = x + vt;
	
    % Crossing the line processing
	lbViolated = xn < lbExtended;
	ubViolated = xn > ubExtended;
	xn (lbViolated) = lbExtended (lbViolated);
	xn (ubViolated) = ubExtended (ubViolated);
	
    % Calculate the fitness value
    for i = 1:PopSize
        Fn(i) = fun (xn(i,:));
    end
    
    for i = 1:PopSize
        t=t+1;if t>T;break;end
        if F(i)>Fn(i)
            F(i)=Fn(i);
            x(i,:)=xn(i,:);
        end
        % Update the black hole
        if BestF>F(i)
            BestF = F(i);                                 % Fitness value of the black hole
            Bestx = x(i,:);                               % Position of black hole
        end
        ConvergenceCurve(t) = BestF;
    end
    


%     if t>T*0.8
%         NumPoints = 100;
%         [SurfX,SurfY] = meshgrid (linspace(lb,ub,NumPoints),linspace(lb,ub,NumPoints));
%         xx = [SurfX(:),SurfY(:)];
%         for i = 1:NumPoints*NumPoints
%             zz(i) = fun(xx(i,:));
%         end
%         SurfZ = reshape(zz,NumPoints,NumPoints);
%         surf (SurfX,SurfY,log(SurfZ), 'EdgeAlpha',0.2);hold on
%         scatter3(x(:,1),x(:,2),log(F),'r','filled');
%         box ('on');
%         title ('Landscape');
% %         view([0,-90])
%         hold off
%         pause(0.01)
%     end
end
