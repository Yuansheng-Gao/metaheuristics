
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  
%  PID-based search algorithm (PSA) source codes version 1.0
%  
%  Developed in:	MATLAB 9.13 (R2022b)
%  
%  Programmer:		Yuansheng Gao
%  
%  Original paper:	Yuansheng Gao,
%                   PID-based search algorithm: A novel metaheuristic 
%                   algorithm based on PID algorithm           
%  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% This function is used to initialize the population
function [x, new_lb, new_ub]=Initialization(PopSize,nvars,ub,lb)

num= size(ub,2); % Number of boundaries
new_lb = lb;
new_ub = ub;

% If the boundaries of all variables are equal and user enter a signle
% number for both ub and lb
if num==1
    x=rand(PopSize,nvars).*(ub-lb)+lb;
    new_lb = lb*ones(1,nvars);
    new_ub = ub*ones(1,nvars);
end

% If each variable has a different lb and ub
if num>1
    for i=1:nvars
        ubi=ub(i);
        lbi=lb(i);
        x(:,i)=rand(PopSize,1).*(ubi-lbi)+lbi;
    end
end