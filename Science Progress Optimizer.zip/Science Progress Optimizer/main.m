%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                         %
%  Science Progress Optimizer (SPO) source codes version 1.0              %
%                                                                         %
%  Developed in:   MATLAB R2018b                                          %
%                                                                         %
%  Programmer:     Yuansheng Gao                                          %
%                  e-mail: gaoyuansheng2021@163.com                       %
%                                                                         %
%  Original paper: Yuansheng Gao, Jinpeng Wang#, Lang Qin#, Jiahui Zhang, %
%                  Yulin Wang     # Equal contribution                    %
%				   Let All Be Guides! Science Progress Optimizer for      %
%                  Global Optimization                                    %
%                                                                         %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% You can simply define your cost in a seperate file and load its handle to fun 
% The initial parameters that you need are:
%__________________________________________
% fun = @YourCostFunction
% dim = number of your variables
% structure.T = maximum number of function evaluations
% structure.PopSize = the size of the population
% lb=[lb1,lb2,...,lbn] where lbn is the lower bound of variable n
% ub=[ub1,ub2,...,ubn] where ubn is the upper bound of variable n
% If all the variables have equal lower bound you can just
% define lb and ub as two single number numbers
%__________________________________________
% SPO will return the following: 
% x                : Best solution found 
% fval             : Objective function value of the found solution 
% ConvergenceCurve : Convergence curve
clear
clc
close all
%% Input
D = 50;
structure.PopSize = 50; % The size of the population
structure.T  = 10000*D; % Maximum number of function evaluations
FunctionName = 'F1';
%% Run Science Progress Optimizer
[lb,ub,dim,fun] = GetFunctionsDetails(FunctionName);
[x,fval,ConvergenceCurve] = SPO (fun,dim,lb,ub,structure);
%% Plot Results
figure
semilogy(ConvergenceCurve);
xlabel('FEs')
ylabel('Log The best function values')
title(FunctionName)