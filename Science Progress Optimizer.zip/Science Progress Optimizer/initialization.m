%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                         %
%  Science Progress Optimizer (SPO) source codes version 1.0              %
%                                                                         %
%  Developed in:   MATLAB R2018b                                          %
%                                                                         %
%  Programmer:     Yuansheng Gao                                          %
%                  e-mail: gaoyuansheng2021@163.com                       %
%                                                                         %
%  Original paper: Yuansheng Gao, Jinpeng Wang, Lang Qin                  %
%				   Science Progress Optimizer: Making the Best Solution   %
%                  Guidance Unnecessary                                   %
%                                                                         %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% This function is used to initialize the population
function x=initialization(PopSize,dim,ub,lb)

num= size(ub,2); % Number of boundaries

% If the boundaries of all variables are equal and user enter a signle
% number for both ub and lb
if num==1
    x=rand(PopSize,dim).*(ub-lb)+lb;
end

% If each variable has a different lb and ub
if num>1
    for i=1:dim
        ubi=ub(i);
        lbi=lb(i);
        x(:,i)=rand(PopSize,1).*(ubi-lbi)+lbi;
    end
end