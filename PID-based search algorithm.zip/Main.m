
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  
%  PID-based search algorithm (PSA) source codes version 1.0
%  
%  Developed in:	MATLAB 9.13 (R2022b)
%  
%  Programmer:		Yuansheng Gao
%  
%  Original paper:	Yuansheng Gao,
%                   PID-based search algorithm: A novel metaheuristic 
%                   algorithm based on PID algorithm           
%  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% fun   : @YourFunction
% nvars : number of decision/design variables
% lb    : lower bound of decision variables
% % ub    : upper bound of decision variables
%
% PSA will return the following:
% x     : best solution found
% fval  : objective function value of the found solution

clc
clear
close all
%% Inputs
PopSize = 50;          % Population size
MaxIter = 500;         % Maximum iterations
FunctionName = 'F1';   % Function number: F1~F23
%% Run PSA
[lb,ub,nvars,fun] = GetFunctionsDetails(FunctionName);
[x,fval,ConvergenceCurve] = PSA (fun,nvars,lb,ub,PopSize,MaxIter);
%% Plot result
figure
plot(ConvergenceCurve,'r','LineWidth',2);
title('Convergence Curve');
xlabel('Iterations');
ylabel('Best value')