Love Evolution Algorithm (LEA)
 
email: gaoyuansheng2021@163.com

The files in this zip archive are MATLAB m-files that can be used to study the Love Evolution Algorithm.

The LEA is the method that I invented and wrote about in the following paper:
Yuansheng Gao, Jiahui Zhang, Yulin Wang, Jinpeng Wang, Lang Qin, Linfu Peng. Love Evolution Algorithm: A Stimulus-Value-Role Theory Inspired Evolutionary Algorithm for Global Optimization.

The MATLAB files and their descriptions are as follows:
GetFunctionsDetails.m
This is the benchmark functions. You can use it as template to write your own function if you are interested in testing or optimizing some other functions. 
LEA.m
This is the core code of the LEA.
Initialization.m
This contains various initialization settings for the optimization methods. 
I hope that this software is as interesting and useful to you as is to me. Feel free to contact me with any comments or questions.