
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  
%  Love Evolution Algorithm (LEA) source codes version 1.0
%  
%  Developed in:	MATLAB 9.13 (R2022b)
%  
%  Programmer:		Yuansheng Gao (e-mail: gaoyuansheng2021@163.com)
%  
%  Original paper:	Yuansheng Gao, Jiahui Zhang, Yulin Wang
%					Jinpeng Wang, Lang Qin.
%					Love Evolution Algorithm: a stimulus-value-role theory 
%                   inspired evolutionary algorithm for global optimization, 
%                   The Journal of Supercomputing.
%             
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% To use this code in your own project 
% remove the line for 'GetFunctionDetails' function 
% and define the following parameters: 
% fun  : function handle to the .m file containing the objective function
%	     the .m file you define should accept the whole population 'x' 
%	     as input and return a column vector containing objective function 
%	     values of all of the population members
% dim  : number of decision/design variables 
% lb   : lower bound of decision variables (must be of size 1 x nvars)
% ub   : upper bound of decision variables (must be of size 1 x nvars)
%
% LEA will return the following: 
% x    : best solution found 
% fval : objective function value of the found solution 

clc
clear
close all
%% Inputs 
D = 50;               % Number of decision/design variables
N = 50;               % Population size
MaxFEs  = 10000*D;    % Maximum number of function evaluations
FunctionName = 'F1';  % Function number: F1~F30 except for F2
%% Run Love Evolution Algorithm
[lb,ub,dim,fun] = GetFunctionsDetails (FunctionName,D);
[x,fval,ConvergenceCurve] = LEA (fun,dim,lb,ub,N,MaxFEs);
%% Plot result
figure
plot(ConvergenceCurve,'r','LineWidth',2);
title('Convergence Curve');
xlabel('Maximum number of function evaluations');
ylabel('The best value')